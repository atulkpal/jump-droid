---
name: Jump Droid Orbit
colors:
  surface: '#0f1419'
  surface-dim: '#0f1419'
  surface-bright: '#353940'
  surface-container-lowest: '#0a0e14'
  surface-container-low: '#181c22'
  surface-container: '#1c2026'
  surface-container-high: '#262a30'
  surface-container-highest: '#31353b'
  on-surface: '#dfe2ea'
  on-surface-variant: '#bfc7d4'
  inverse-surface: '#dfe2ea'
  inverse-on-surface: '#2d3137'
  outline: '#89919d'
  outline-variant: '#404752'
  surface-tint: '#9ecaff'
  primary: '#9ecaff'
  on-primary: '#003258'
  primary-container: '#2196f3'
  on-primary-container: '#002c4f'
  inverse-primary: '#0061a4'
  secondary: '#f9abff'
  on-secondary: '#570066'
  secondary-container: '#86039c'
  on-secondary-container: '#f7a0ff'
  tertiary: '#ffb77b'
  on-tertiary: '#4d2700'
  tertiary-container: '#db7900'
  on-tertiary-container: '#452200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#9ecaff'
  on-primary-fixed: '#001d36'
  on-primary-fixed-variant: '#00497d'
  secondary-fixed: '#ffd6fe'
  secondary-fixed-dim: '#f9abff'
  on-secondary-fixed: '#35003f'
  on-secondary-fixed-variant: '#7b008f'
  tertiary-fixed: '#ffdcc2'
  tertiary-fixed-dim: '#ffb77b'
  on-tertiary-fixed: '#2e1500'
  on-tertiary-fixed-variant: '#6d3900'
  background: '#0f1419'
  on-background: '#dfe2ea'
  surface-variant: '#31353b'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  stats-num:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 24px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-padding: 20px
  stack-gap: 12px
---

## Brand & Style
The design system for this mobile title centers on a high-fidelity, futuristic space aesthetic. It targets mobile gamers seeking a premium, immersive experience. The visual language utilizes **Glassmorphism** to create a sense of depth and atmospheric perspective, simulating high-tech HUDs (Heads-Up Displays) floating against the vastness of deep space. 

The emotional response should be one of "Tactile Technology"—where every UI element feels like a physical piece of a starship's bridge or a droid's internal visor. The style combines the sleekness of modern technology with the mysterious allure of the cosmos, using vibrant neon accents to punctuate a dark, expansive canvas.

## Colors
The palette is rooted in a deep space "Void Black" (#0A0A1A) to maximize contrast for gameplay elements. Glass surfaces use a slightly lighter, desaturated navy (#1A1A2E) with 80% opacity to maintain legibility.

Accent colors are functional and tiered:
- **Status/Progression**: Blue handles active states, while Yellow signals a "near-win" urgency.
- **Rank/Rarity**: A spectrum from Green (common/entry) to Purple (advanced) and Gold (legendary/elite).
- **Interactive Elements**: Use the primary Blue for primary actions to maintain a consistent mechanical feel.

## Typography
The typography system uses three distinct sans-serifs to establish a technical hierarchy:
- **Display & Headlines**: Use **Sora** for its wide, geometric structure which feels futuristic and authoritative.
- **Body**: Use **Hanken Grotesk** for high readability at smaller scales during gameplay tutorials or lore descriptions.
- **Data & UI Labels**: Use **Space Grotesk** for its slightly monospaced, technical feel, perfect for timers, scores, and status tags.

All primary text is pure White (#FFFFFF), with secondary information and "flavor text" set in Gray (#9E9E9E) to reduce visual noise.

## Layout & Spacing
This design system utilizes a **Fluid Grid** model optimized for mobile handsets. The base spacing unit is 4px, ensuring all elements align to a consistent rhythmic scale.

- **Margins**: A standard 20px safe area is maintained on the left and right edges of the screen.
- **Gaps**: Vertical stacks for mission lists or droid upgrades use a 12px gap.
- **Safe Zones**: Account for "notch" and "home indicator" areas on modern smartphones by applying dynamic padding to top and bottom containers.

## Elevation & Depth
Depth is achieved through **Backdrop Blurs** rather than traditional drop shadows.
1. **Background**: Deep space base layer (#0A0A1A).
2. **Cards/Panels**: Surface (#1A1A2E) at 80% opacity with a 16px blur effect. This creates a "frosted glass" look that lets background nebulae or stars peek through.
3. **Borders**: Each glass panel has a 1px inner stroke using a white-to-transparent linear gradient (top-left to bottom-right) at 15% opacity to define the "edge" of the glass.
4. **Active State**: Elevated interactive elements use a subtle outer glow (0px 0px 12px) colored with the primary accent to indicate selection.

## Shapes
The design system utilizes a **Pill-shaped** language for secondary UI elements (tags, badges, chips) to provide a soft contrast against the rigid, technical grid. 

- **Primary Containers**: Large cards use a 24px corner radius.
- **Interactive Elements**: Buttons and tags are fully rounded (pill-shaped) to signify "touchability."
- **Progress Indicators**: The ends of progress bars are rounded to match the pill-shaped container motif.

## Components

### Buttons & Tags
- **Action Buttons**: Solid #2196F3 with white text. High roundedness.
- **Status Tags**: Pill-shaped with a 1px border matching the status color (e.g., Rookie = Green) and a 10% opacity fill of the same color.

### Progress Bars
- **Style**: Ultra-thin (4px height) linear tracks. 
- **Fill**: Linear gradient from the accent color (e.g., Blue for In-Progress) to a brighter tint of the same hue. 
- **Background**: Darker, 20% opacity version of the track color.

### Cards
- **Mission Cards**: Glass-morphic background with a subtle "locked" overlay if necessary. 
- **Header**: Contains the title and the pill-shaped status tag in the top right.

### Icons
- **Checkmarks**: Used for "Almost Complete" and "Finished" states, always utilizing the accent color of the state.
- **Padlocks**: Minimalist, thin-line icons used for locked levels or droids, typically rendered in secondary gray.

### Droid Profiles
- Circular avatars with a "Rarity Ring"—a 2px border around the avatar using the Rookie/Experienced/Elite color spectrum.